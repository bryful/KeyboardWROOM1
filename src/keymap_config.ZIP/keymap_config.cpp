#include "keymap_config.hpp"

void loadKeyConfigFromJson11(KeyConfig *keyConfigs, const KeyConfig *defaultKeyConfigs, const char *filename)
{
    if (!LittleFS.begin())
    {
        memcpy(keyConfigs, defaultKeyConfigs, sizeof(KeyConfig) * KEY_MATRIX_SIZE);
        return;
    }
    File f = LittleFS.open(filename, "r");
    if (!f)
    {
        memcpy(keyConfigs, defaultKeyConfigs, sizeof(KeyConfig) * KEY_MATRIX_SIZE);
        return;
    }
    JsonDocument doc;
    DeserializationError err = deserializeJson(doc, f);
    if (err)
    {
        memcpy(keyConfigs, defaultKeyConfigs, sizeof(KeyConfig) * KEY_MATRIX_SIZE);
        f.close();
        return;
    }
    JsonArray arr = doc.as<JsonArray>();
    int i = 0;
    for (JsonObject obj : arr)
    {
        if (i >= KEY_MATRIX_SIZE)
            break;
        keyConfigs[i].function = (KeyFunction)obj["function"].as<int>();
        keyConfigs[i].primaryKey = obj["primaryKey"].as<uint8_t>();
        keyConfigs[i].modifiers = obj["modifiers"].as<uint8_t>();
        i++;
    }
    f.close();
}

void saveKeyConfigToJson11(KeyConfig *keyConfigs, const char *filename)
{
    if (!LittleFS.begin())
        return;
    File f = LittleFS.open(filename, "w");
    if (!f)
        return;
    JsonDocument doc;
    JsonArray arr = doc.to<JsonArray>();
    for (int i = 0; i < KEY_MATRIX_SIZE; i++)
    {
        JsonObject obj = arr.add<JsonObject>();
        obj["function"] = (int)keyConfigs[i].function;
        obj["primaryKey"] = keyConfigs[i].primaryKey;
        obj["modifiers"] = keyConfigs[i].modifiers;
    }
    serializeJsonPretty(doc, f);
    f.close();
}

void resetKeyConfigToDefault11(KeyConfig *keyConfigs, const KeyConfig *defaultKeyConfigs)
{
    memcpy(keyConfigs, defaultKeyConfigs, sizeof(KeyConfig) * KEY_MATRIX_SIZE);
}
