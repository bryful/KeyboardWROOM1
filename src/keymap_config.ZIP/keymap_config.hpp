#pragma once
#include "keypad_common.hpp"
#include <ArduinoJson.h>
#include <LittleFS.h>

void loadKeyConfigFromJson11(KeyConfig *keyConfigs, const KeyConfig *defaultKeyConfigs, const char *filename);
void saveKeyConfigToJson11(KeyConfig *keyConfigs, const char *filename);
void resetKeyConfigToDefault11(KeyConfig *keyConfigs, const KeyConfig *defaultKeyConfigs);
